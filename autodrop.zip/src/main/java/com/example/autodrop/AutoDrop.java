package com.example.autodrop;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;

@Environment(EnvType.CLIENT)
public class AutoDrop implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GenericContainerScreen containerScreen) {
                int x = containerScreen.x + containerScreen.backgroundWidth - 55;
                int y = containerScreen.y - 20;

                ButtonWidget button = ButtonWidget.builder(Text.of("DropAll"), (btn) -> {
                    dropAll(containerScreen);
                }).dimensions(x, y, 50, 20).build();

                ScreenEvents.getScreenHandler(screen).addDrawableChild(button);
            }
        });
    }

    private void dropAll(GenericContainerScreen screen) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (player == null) return;

        for (int i = 0; i < screen.getScreenHandler().slots.size(); i++) {
            client.interactionManager.clickSlot(
                screen.getScreenHandler().syncId,
                i,
                1, // right click = throw toàn stack
                SlotActionType.THROW,
                player
            );
        }
    }
}
